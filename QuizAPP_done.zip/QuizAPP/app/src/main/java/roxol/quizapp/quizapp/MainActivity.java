package roxol.quizapp.quizapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

import cn.pedant.SweetAlert.SweetAlertDialog;

public class MainActivity extends AppCompatActivity {

    TextView questionLabel, questionCountLabel, scoreLabel;
    EditText answerEdit;
    Button submitButton;
    ProgressBar progressBar;
    ArrayList<QuestionModel> questionModelArrayList;

    int currentPosition = 0;
    int numberOfCorrectAnswer = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionCountLabel = findViewById(R.id.noQuestion);
        questionLabel = findViewById(R.id.question);
        scoreLabel = findViewById(R.id.score);

        answerEdit = findViewById(R.id.answer);
        submitButton = findViewById(R.id.submit);
        progressBar = findViewById(R.id.progress);

        questionModelArrayList = new ArrayList<>();

        setUpQuestion();

        setData();

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer();
            }
        });
    }

    public void checkAnswer() {
        String answerString = answerEdit.getText().toString().trim();

        if(answerString.equalsIgnoreCase(questionModelArrayList.get(currentPosition).getAnswer())) {
            numberOfCorrectAnswer++;

            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                    .setTitleText("Brawo!")
                    .setContentText("Poprawna odpowiedź!")
                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener(){

                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog){
                            currentPosition++;

                            setData();
                            answerEdit.setText("");
                            sweetAlertDialog.dismiss();
                        }
                    })
                    .show();
        } else {
            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("Odpowiedź błędna!")
                    .setContentText("Poprawna odpowiedź to: " +questionModelArrayList.get(currentPosition).getAnswer())
                    .setConfirmText("OK")
                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener(){

                        @Override
                        public void onClick(SweetAlertDialog sDialog){
                            sDialog.dismiss();

                            currentPosition++;

                            setData();
                            answerEdit.setText("");
                        }
                    })
                    .show();
        }

        int x = ((currentPosition + 1) * 100) / questionModelArrayList.size();

        progressBar.setProgress(x);
    }

    public void setUpQuestion(){
        questionModelArrayList.add(new QuestionModel("2 + 2 * 2 = ?", "6"));
        questionModelArrayList.add(new QuestionModel("Jaś ma 5zł, 2zł dał Kasi. Ile złotych zostało Jasiowi?", "3"));
        questionModelArrayList.add(new QuestionModel("Max w pracy miał wypisać numery na tabliczki domów z ulicy Kwiatowej. Ma przygotować numery od 1 do 100. Ile razy będzie wypisywał cyfrę 8?", "20"));
        questionModelArrayList.add(new QuestionModel("Jeśli pomnożysz mnie przez inną liczbę, wynik zawsze będzie taki sam. Jaką jestem liczbą?", "0"));
        questionModelArrayList.add(new QuestionModel("Zofia ma 5 córek, a każda z nich ma brata. Czy potrafisz obliczyć ile dzieci jest w tej rodzinie?", "6"));
        questionModelArrayList.add(new QuestionModel("Ania ma 6 rodzeństwa. Każde z dzieci urodziło się w odstępie 2 lat. Najmłodsza jest Julia, która ma 7 lat. Ile lat ma najstarsza z rodzeństwa - Ania?", "19"));
        questionModelArrayList.add(new QuestionModel("Jedziesz trzeci, wyprzedziłeś drugiego. Który jesteś?", "2"));
        questionModelArrayList.add(new QuestionModel("Cegła waży 2kg i pół cegły. Ile waży cegła?", "4"));
    }

    public void setData(){

        if(questionModelArrayList.size()>currentPosition) {

            questionLabel.setText(questionModelArrayList.get(currentPosition).getQuestionString());

            scoreLabel.setText("Punkty :" + numberOfCorrectAnswer + "/" + questionModelArrayList.size());
            questionCountLabel.setText("Pytanie : " + (currentPosition + 1));


        }else{


            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.SUCCESS_TYPE)
                    .setTitleText("Zakończyłeś/aś quiz")
                    .setContentText("Zdobyte punkty: "+ numberOfCorrectAnswer + "/" + questionModelArrayList.size())
                    .setConfirmText("Spróbuj ponownie")
                    .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {

                            sDialog.dismissWithAnimation();
                            currentPosition = 0;
                            numberOfCorrectAnswer = 0;
                            progressBar.setProgress(0);
                            setData();
                        }
                    })
                    .setCancelText("Zamknij")
                    .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sDialog) {

                            sDialog.dismissWithAnimation();
                            finish();
                        }
                    })
                    .show();

        }
    }
}